#include "Queen.h"

//A queen may move any number of spaces in one direction, including diagonally. A queen may not move through other pieces
namespace Chess {
  bool Queen::legal_move_shape(const Position& start, const Position& end) const{
    int row_diff = abs(end.second - start.second);
    int col_diff = abs(end.first - start.first);


    //see if move shape is legal
    if (start.first == end.first || start.second == end.second ){
      return true;
    } 
    else if(row_diff == col_diff) {
      return true;
    }
    
    return false;
  }
}

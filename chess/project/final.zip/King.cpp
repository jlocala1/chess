#include "King.h"


//A king may move in any direction, including diagonally, but may only move one square.
namespace Chess {
  bool King:: legal_move_shape(const Position& start, const Position& end) const {
      int row_diff = abs(end.second - start.second);
      int col_diff = abs(end.first - start.first);
        
      //see if move shape is legal
      if((row_diff == 1 && col_diff == 1) || (row_diff == 1 && col_diff == 0) || (row_diff == 0 && col_diff == 1)) {
      return true;
    }

    return false;
  }
}
  

#include <iostream>
#include <utility>
#include <map>
#ifndef _WIN32
#include "Terminal.h"
#endif // !_WIN32
#include "Board.h"
#include "CreatePiece.h"
#include "Exceptions.h"

namespace Chess
{
  /////////////////////////////////////
  // DO NOT MODIFY THIS FUNCTION!!!! //
  /////////////////////////////////////
  Board::Board(){}
  const Piece* Board::operator()(const Position& position) const {
    std::map<Position, Piece*>::const_iterator it = occ.find(position); //find piece at wanted position
    if (it != occ.end()) { //check that the iterator found that position before the end of the map
      return it->second; //return pointer to the piece at that position
    }
    else {
      return nullptr; //return null if nothing is there
    }
  }

  void Board::add_piece(const Position& position, const char& piece_designator) {
    
    //Make sure the designator is valid 
    if (!is_valid_designator(piece_designator)) {
      throw Chess::Exception("Invalid designator: Game ended");
    }

    //Check if the position is on the board
    if (!is_valid_position(position)) {
      throw Chess::Exception("Invalid position: Please try again!");
    }

    //Check if the position is occupied
    if (occ.find(position) != occ.end()) {
      throw Chess::Exception("Position is occupied: Please try again!");
    }
    //Create the piece and add it to the board if none of the exception are thrown
    occ[position] = create_piece(piece_designator);
  }


  //Helper functions for add_piece
  bool Board::is_valid_designator(const char& piece_designator) const {
    //Check if the designator is one of the valid requirements
    return (piece_designator == 'K' || piece_designator == 'Q' || piece_designator == 'R' ||
	    piece_designator == 'N' || piece_designator == 'B' || piece_designator == 'P' || piece_designator == 'M' ||
	    piece_designator == 'k' || piece_designator == 'q' || piece_designator == 'r' || piece_designator == 'n' ||
	    piece_designator == 'b' || piece_designator == 'p' || piece_designator == 'm' || piece_designator == '-');
  }

  bool Board::is_valid_position(const Position& position) const {
    // Check if the position is within the bounds of the chessboard (A1 to H8)
    char file = position.first;
    char rank = position.second;
    return (file >= 'A' && file <= 'H' && rank >= '1' && rank <= '8');
  }

  void Board::display() const {
    std::cout << "w" << std::endl;
    // Loop through each row and column of the board
    for (char row = '1'; row <= '8'; row++) {
      for (char col = 'A'; col <= 'H'; col++) {
	Position pos(col, row);
	const Piece* piece = operator()(pos); // Get the piece at the current position

	// Determine the foreground and background colors based on the position
	if ((col + row) % 2 == 0) {
	  Terminal::color_bg(Terminal::WHITE); // Set background color to yellow for light squares
	  Terminal::color_fg(true, Terminal::BLUE);
	}
	else {
	  Terminal::color_bg(Terminal::BLUE); // Set background color to blue for dark squares
	  Terminal::color_fg(true, Terminal::WHITE);
	}

	// Print the piece symbol or a dash if the square is empty
	if (piece != nullptr) {
	  std::cout << piece->to_ascii() << ' '; // Print the ASCII representation of the piece
	}
	    
	else {
	     
	  std::cout << "  "; // Print two spaces
	}
      }
      // Reset the colors to default after printing the row
      Terminal::set_default(); // Reset colors to default after printing the row

      // Move to the next row
      std::cout << std::endl;
    }
    std::cout << "b" << std::endl;    
  }
  bool Board::has_valid_kings() const {
    int white_king_count = 0;
    int black_king_count = 0;
    for (std::map<std::pair<char, char>, Piece*>::const_iterator it = occ.begin();
	 it != occ.end();
	 it++) {
      if (it->second) {
	switch (it->second->to_ascii()) {
	case 'K':
	  white_king_count++;
	  break;
	case 'k':
	  black_king_count++;
	  break;
	}
      }
    }
    return (white_king_count == 1) && (black_king_count == 1);
  }
  
  /////////////////////////////////////
  // DO NOT MODIFY THIS FUNCTION!!!! //
  /////////////////////////////////////
  std::ostream& operator<<(std::ostream& os, const Board& board) {
    for(char r = '8'; r >= '1'; r--) {
      for(char c = 'A'; c <= 'H'; c++) {
	const Piece* piece = board(Position(c, r));
	if (piece) {
	  os << piece->to_ascii();
	} else {
	  os << '-';
	}
      }
      os << std::endl;
    }
    return os;
  }



  // return true if position is valid square on board
  bool Board::position_exists(const Position& pos) {
    if(pos.first >= 'A' && pos.first <= 'H'
       && pos.second >= '1' && pos.second <= '8') {
      return true;
    }
    else {
      return false;
    }
  }

  Position Board::find_king(const bool& white) const {
    for (std::map<std::pair<char, char>, Piece*>::const_iterator it = occ.begin();
	 it != occ.end();
	 it++) {
      if (it->second) {
	if (white && it->second->to_ascii() == 'K') {
	  return it->first;
	}
	else if(!white && it->second->to_ascii() == 'k') {
	  return it->first;
	}
      }
    }
    //there should always be a king on the board
    return Position('Z','-1');
  }

  void Board::move_piece(const Position& start, const Position& end) {
    remove_piece(end);
    occ[end] = occ[start];
    occ.erase(start);
  }
  

  void Board::remove_piece(const Position& pos) {
    delete occ[pos];
    occ.erase(pos);
  }


}

#include "Pawn.h"
#include <cstdlib>
#include "Board.h"
#include "Piece.h"

//A pawn can move only forward towards the opponent’s side of the board, but with restrictions. On its first move of the game, a pawn may move forward either one or two squares; on subsequent moves, a pawn may only move forward one square. A pawn may not move through other pieces. Furthermore, the pawn may not use a forward move to land in a square that is occupied by any player’s piece. In a separate type of action, a pawn may make a special move to “capture” an opponent piece 

namespace Chess {

    bool Pawn::legal_move_shape(const Position& start, const Position& end) const {
        int col_diff = end.first - start.first; //Sees if it is staying within the same row
        int row_diff = end.second - start.second; //Sees if staying within the same column

        // Determine the color of the pawn using is_white()
        if (is_white()) {
           // Allow diagonal movement for capturing
           if (col_diff == 1 || col_diff == -1) {
             return (row_diff == 1);
            }
        return (col_diff == 0 && (row_diff == 1 || (start.second == '2' && row_diff == 2)));
         } else {
            // Allow diagonal movement for capturing
              if (col_diff == 1 || col_diff == -1) {
                 return (row_diff == -1);
              }
        return (col_diff == 0 && (row_diff == -1 || (start.second == '7' && row_diff == -2)));
         }
     }


    bool Pawn::legal_capture_shape(const Position& start, const Position& end) const {
        int row_diff = end.first - start.first; // Use first instead of row
        int col_diff = abs(end.second - start.second); // Use second instead of col

        // Determine the color of the pawn using is_white()
        if (is_white()) {
            return (row_diff == 1 && col_diff == 1); // Diagonal move for capturing
        } else {
            return (row_diff == -1 && col_diff == 1); // Diagonal move for capturing
        }
    }

} // namespace Chess

#include "Rook.h"


// A rook may move any number of squares, but only along a horizontal or vertical line on the board. A rook may not move through other pieces.

namespace Chess
{
    bool Rook::legal_move_shape(const Position& start, const Position& end) const {
        // Check if the start and end positions are on the same row or column
        if (start.first != end.first && start.second != end.second) {
            return false; // Rooks can only move along rows or columns
        }

        // If the move is along a row or a column, it's a legal move for a rook
        return true;
    }
}

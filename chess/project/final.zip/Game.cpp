#include <cassert>
#include<string>
#include<sstream>
#include "Game.h"
#include "Board.h"
#include <vector>

namespace Chess
{
  /////////////////////////////////////
  // DO NOT MODIFY THIS FUNCTION!!!! //
  /////////////////////////////////////
  Game::Game() : is_white_turn(true) {
    // Add the pawns
    for (int i = 0; i < 8; i++) {
      board.add_piece(Position('A' + i, '1' + 1), 'P');
      board.add_piece(Position('A' + i, '1' + 6), 'p');
    }

    // Add the rooks
    board.add_piece(Position( 'A'+0 , '1'+0 ) , 'R' );
    board.add_piece(Position( 'A'+7 , '1'+0 ) , 'R' );
    board.add_piece(Position( 'A'+0 , '1'+7 ) , 'r' );
    board.add_piece(Position( 'A'+7 , '1'+7 ) , 'r' );

    // Add the knights
    board.add_piece(Position( 'A'+1 , '1'+0 ) , 'N' );
    board.add_piece(Position( 'A'+6 , '1'+0 ) , 'N' );
    board.add_piece(Position( 'A'+1 , '1'+7 ) , 'n' );
    board.add_piece(Position( 'A'+6 , '1'+7 ) , 'n' );

    // Add the bishops
    board.add_piece(Position( 'A'+2 , '1'+0 ) , 'B' );
    board.add_piece(Position( 'A'+5 , '1'+0 ) , 'B' );
    board.add_piece(Position( 'A'+2 , '1'+7 ) , 'b' );
    board.add_piece(Position( 'A'+5 , '1'+7 ) , 'b' );

    // Add the kings and queens
    board.add_piece(Position( 'A'+3 , '1'+0 ) , 'Q' );
    board.add_piece(Position( 'A'+4 , '1'+0 ) , 'K' );
    board.add_piece(Position( 'A'+3 , '1'+7 ) , 'q' );
    board.add_piece(Position( 'A'+4 , '1'+7 ) , 'k' );
  }

  void Game::make_move(const Position& start, const Position& end) {
    if (!board.position_exists(start)) {
      throw Exception("start position is not on board");
    }
    if (!board.position_exists(end)) {
      throw Exception("end position is not on board");
    }
    if (board(start) == nullptr) {
      throw Exception("no piece at start position");
    }
    if (is_white_turn != board(start)->is_white()) {
      throw Exception("piece color and turn do not match");
    }
    // non-capture move
    if(board(end) == nullptr) {
      if (!(board(start)->legal_move_shape(start, end))) {
	throw Exception("illegal move shape");
      }
    }
    // capture move
    else if(board(end) != nullptr) {
      if (board(end)->is_white() == is_white_turn) {
	throw Exception("cannot capture own piece");
      }
      if (!(board(start)->legal_capture_shape(start, end))) {
	throw Exception("illegal capture shape");
      }
    }
    if(path_clear(start, end)) {
      throw Exception("path is not clear");
    }
    
    // check if move results in exposing own king (you cannot check your own pieces)
    Game game_copy(*this);
    game_copy.board.move_piece(start, end);
    game_copy.promote_pawn(end);
    if (game_copy.in_check(is_white_turn)) {
      throw Exception("move exposes check");
    }
    else {
      board.move_piece(start, end);
      promote_pawn(end);
      is_white_turn = !is_white_turn;
    }

  }

  bool Game::in_check(const bool& white) const {
    Position king_pos = board.find_king(white);
    // iterate through board
    for(char col = 'A'; col <= 'H'; col++) {
      for(char row = '1'; row <= '8'; row++) {
	Position curr_pos(col,row);
	if ((board(curr_pos) != nullptr) && (board(curr_pos)->is_white() == !white)
	    && board(curr_pos)->legal_capture_shape(curr_pos, king_pos)
	    && !path_clear(curr_pos, king_pos)) {
	  return true;
	}
      }
    }
    return false;
  }


  bool Game::in_mate(const bool& white) const {
    if (!in_check(white)) {//if it is not in check then it cannot be in checkmate
      return false;
    }
    //create a temporary game to brute force check if the game is in checkmate 
    Game game_copy(*this);
    for(char col = 'A'; col <= 'H'; col++) {
      for(char row = '1'; row <= '8'; row++) {
	Position curr_start_pos(col,row);
	if(game_copy.board(curr_start_pos) && game_copy.board(curr_start_pos)->is_white() == white) {

	  for(char col = 'A'; col <= 'H'; col++) {
	    for(char row = '1'; row <= '8'; row++) {
	      Position curr_end_pos(col,row);
	      try {
		game_copy.make_move(curr_start_pos, curr_end_pos);
		return false;
	      }
	      catch (Exception&) {
		continue;
	      }
	    }
	  }
	}
      }
    }
    return true;
  }


  bool Game::in_stalemate(const bool& white) const {
    if (in_check(white)) {
      return false;
    }
    Game game_copy(*this);
    for(char col = 'A'; col <= 'H'; col++) {
      for(char row = '1'; row <= '8'; row++) {
	Position curr_start_pos(col,row);
	if(game_copy.board(curr_start_pos) && game_copy.board(curr_start_pos)->is_white() == white) {

	  for(char col = 'A'; col <= 'H'; col++) {
	    for(char row = '1'; row <= '8'; row++) {
	      Position curr_end_pos(col,row);
	      try {
		game_copy.make_move(curr_start_pos, curr_end_pos);
		return false;
	      }
	      catch (Exception& e) {
		continue;
	      }
	      return true;
	    }
	  } // end inner double for loop
	}
      }
    } // end outer double for loop
    return true;
  }

  int Game::point_value(const bool& white) const {
    int value = 0;

    for (char row = '1'; row <= '8'; ++row) {
      for (char col = 'A'; col <= 'H'; ++col) {
	const Piece* piece = board(Position(col, row));
	if (piece != nullptr && piece->is_white() == white) {
	  // Increment the value based on the type of piece
	  switch (piece->to_ascii()) {
	  case 'K':
	  case 'k':
	    value += 0; // King
	    break;
	  case 'Q':
	  case 'q':
	    value += 9; // Queen
	    break;
	  case 'R':
	  case 'r':
	    value += 5; // Rook
	    break;
	  case 'B':
	  case 'b':
	  case 'N':
	  case 'n':
	    value += 3; // Bishop or Knight
	    break;
	  case 'P':
	  case 'p':
	    value += 1; // Pawn
	    break;
	  }
	}
      }
    }

    return value;
  }


  //REmoves all of teh old pieces of teh game board to load the new game board                                                                                                       
    //in its place                                                                                                                                                                     
    void Board::erase(Board& board) {
      // Loop through the board and remove all pieces                                                                                                                                  
      for (int row = 'A'; row <= 'H'; ++row) {
	for (int col = '1'; col <= '8'; ++col) {
	  board.remove_piece((Position(row,col)));
	}
      }
    }
  
  std::istream& operator>>(std::istream& is, Game& game) {
      std::string line;
      char row_char = '8'; // Start with the 8th row (top row in the file)

      game.board.erase(game.board); // Clear the board before loading new state

      // Read the 8 rows of the board
      for (int i = 0; i < 8; ++i) {
	if (!std::getline(is, line) || line.length() != 8) {
	  throw std::runtime_error("Each line must contain exactly 8 characters representing one row of the board."); 
	}

	char col_char = 'A'; // Start with column A
	for (char piece : line) { //CHANGE 
	  if (piece != '-') {
	    Position pos(col_char, row_char);
	    game.board.add_piece(pos, piece);
	  }
	  col_char++; // Move to the next column
	}
	row_char--; // Move to the next row (decrement row character)
      }

      // After reading board, read whose turn it is
      if (!std::getline(is, line) || line.length() != 1 || (line[0] != 'w' && line[0] != 'W' && line[0] != 'b' && line[0] != 'B')) {
	throw std::runtime_error("Invalid input: turn must be 'w', 'W', 'b', or 'B'.");
      }

      game.is_white_turn = (line[0] == 'w' || line[0] == 'W');
      return is;
    }

  /////////////////////////////////////
  // DO NOT MODIFY THIS FUNCTION!!!! //
  /////////////////////////////////////
  std::ostream& operator<< (std::ostream& os, const Game& game) {
    // Write the board out and then either the character 'w' or the character 'b',
    // depending on whose turn it is
    return os << game.board << (game.turn_white() ? 'w' : 'b');
  }


  // function to determine if path is blocked
  bool Game::path_clear(const Position& start, const Position& end) const {
    int col_diff = abs(end.first - start.first);
    int row_diff = abs(end.second - start.second);

    // check column
    if (col_diff == 0 && row_diff != 0) {
      if (row_diff < 0) {
	for (int i = (row_diff - 1); i > 0; i--) {
	  Position curr_pos(start.first, start.second - i);
	  //check if teh piece is a null pointer
	  if (board(curr_pos) != nullptr) {
	    return true;
	  }
	}
      }
    }      
      // check row
      else if  (row_diff == 0 && col_diff != 0) {
	if(col_diff < 0) {
	  for (int i = (col_diff - 1); i > 0; i--) {
	    Position curr_pos(start.first - i, start.second);
	    if (board(curr_pos) != nullptr) {
	      return true;
	    }
	  }
	}
      } 
	// check diaganols
      
	else if (col_diff == row_diff) {
	  // upper right diagonal
	  if (col_diff > 0 && row_diff > 0) {
	    for (int i = 1; i < col_diff; i++) {
	      Position curr_pos(start.first + i, start.second + i);
	      if (board(curr_pos) != nullptr) {
		return true;
	      }
	    }
	  }
	}
	  // cupper left diagonal
	  else if (col_diff < 0 && row_diff > 0) {
	    for (int i = 1; i < col_diff; i++) {
	      Position curr_pos(start.first - i, start.second + i);
	      if (board(curr_pos) != nullptr) {
		return true;
	      }
	    }
	  }

	  // bottom left diagonal
	  else if (col_diff < 0 && row_diff < 0) {
	    for (int i = 1; i < col_diff; i++) {
	      Position curr_pos(start.first - i, start.second - i);
	      if (board(curr_pos) != nullptr) {
		return true;
	      }
	    }
	  }
	  // bottom right diagonal
	  else if (col_diff > 0 && row_diff < 0) {
	    for (int i = 1; i < col_diff; i++) {
	      Position curr_pos(start.first + i, start.second - i);
	      if (board(curr_pos) != nullptr) {
		return true;
	      }
	    }
	  }
    return false;
  }
  

// Constructor for Game
Game::Game(const Game& tempGame) {
    is_white_turn = tempGame.turn_white();
    for (char col = 'A'; col <= 'H'; col++) {
        for(char row = '8'; row >= '1'; row--) {
            Position curr(col,row);
            if (tempGame.board(curr) != nullptr) {
                board.add_piece(curr, tempGame.board(curr)->to_ascii());
            }
        }
    }
}

// Promote the pawn
void Game::promote_pawn(const Position& end) {
    const Piece* piece = board(end);

    // Check if the piece is a pawn and it reaches the opposing side
    if (piece != nullptr && piece->to_ascii() == 'p' && end.second == '1') {
        board.remove_piece(end);
        board.add_piece(end, 'q'); // Promote to queen
    } else if (piece != nullptr && piece->to_ascii() == 'P' && end.second == '8') {
        board.remove_piece(end);
        board.add_piece(end, 'Q'); // Promote to queen
    }
}

// Override the equals operator so that more easily copy game state
Game& Game::operator=(const Game& newGame) {
    if (this == &newGame) {
        return *this;
    }
    // Clear everything and copy pieces
    is_white_turn = newGame.turn_white();
    for (char col = 'A'; col <= 'H'; col++) {
        for(char row = '8'; row >= '1'; row--) {
            Position curr(col,row);
            if (board(curr) != nullptr) {
                delete board(curr); // Make sure this is correct for your implementation
            }
            if (newGame.board(curr) != nullptr) {
                board.add_piece(curr, newGame.board(curr)->to_ascii());
            }
        }
    }
    return *this;
}

      //Definition for the destructor of Game
      Game::~Game() {
	for (char col = 'A'; col <= 'H'; col++) {
	  for(char row  = '8'; row  >= '1'; row--) {
            Position curr(col,row);
            if (board(curr) != nullptr) {
	      delete board(curr); // Make sure this is correct for your implementation
            }
	  }
	}
      }
 
    }

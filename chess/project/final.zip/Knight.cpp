#include "Knight.h"
#include "Board.h"


//A knight may move in an L-shape, of length either two-by-one or one-by-two. The knight is the only piece that is not stopped by other pieces in its way (i.e. it can move through other pieces to get to an open square).

namespace Chess
{
  bool Knight::legal_move_shape(const Position& start, const Position& end) const {
    int row_diff = abs(end.first - start.first);
    int col_diff = abs(end.second - start.second);    //see if move shape is legal


    if((col_diff == 2 && row_diff == 1) || (col_diff == 1 && row_diff == 2)) {
      return true;
    }
    
    return false;
  }
}

#include "Bishop.h"

namespace Chess
{

  bool Bishop::legal_move_shape(const Position& start, const Position& end) const {
    //get differences between rows & columns
    int col_diff = abs(end.first - start.first);
    int row_diff = abs(end.second - start.second);

    //see if move shape is legal
    if(row_diff == col_diff) {
      return true;
    }
    
    return false;
  }
}
